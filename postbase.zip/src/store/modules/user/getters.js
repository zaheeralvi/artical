export default {
  getUser: (state) => state,
  isLoggedIn:(state) => state.isUserLoggedIn,
  getToken:(state) => state.token,
}
