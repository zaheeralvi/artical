export const SET_NAME = `SET_NAME`;
